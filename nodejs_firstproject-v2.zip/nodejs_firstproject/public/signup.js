document.getElementById('signup-form').addEventListener('submit', async function (event) {
    event.preventDefault(); // Prevent the default form submission

    const username = document.getElementById('signup-username').value;
    const password = document.getElementById('signup-password').value;

    try {
        const response = await fetch('http://localhost:8000/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();
        document.getElementById('message').innerText = data.error || 'Signup successful!';
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('message').innerText = 'An error occurred during signup.';
    }
});