document.getElementById('back-button').addEventListener('click', function() {
    window.location.href = 'http://localhost:8000/index.html'; // Redirect to the dashboard page
});

document.getElementById('create-record-button').addEventListener('click', function() {
    window.location.href = 'create_record.html'; // Navigate to the create record page
});

// Fetch records based on selected type and date range
async function fetchRecords() {
    const token = localStorage.getItem('token');
    if (!token) {
        console.error('No token found. User may not be logged in.');
        return;
    }

    const decodedToken = jwt_decode(token); // Decode the token to get the username
    const username = decodedToken.username; // Get the username from the token
    const recordType = document.getElementById('record-type').value; // Get selected record type
    const startPeriod = document.getElementById('start-period').value;
    const endPeriod = document.getElementById('end-period').value;

    console.log('Fetching records with:', {
        username,
        recordType,
        startPeriod,
        endPeriod
    });

    try {
        const response = await fetch('http://localhost:8000/getRecords', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'token': token
            },
            body: JSON.stringify({
                username: username,
                start_period: startPeriod,
                end_period: endPeriod,
                record_type: recordType // Use the selected record type
            })
        });

        // Check if the response is okay
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const records = await response.json();
        console.log('Fetched Records:', records); // Log the fetched records to the console

        // Populate the records table
        populateRecordsTable(records);
        // Draw the time series chart
        drawChart(records);
    } catch (error) {
        console.error('Error fetching records:', error);
        document.getElementById('message').innerText = 'An error occurred while fetching records.';
    }
}

// Populate the records table
function populateRecordsTable(records) {
    const tableBody = document.getElementById('records-table').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = ''; // Clear existing rows

    records.forEach(record => {
        console.log('Record object:', record); // Log the record object to check its structure

        const row = tableBody.insertRow();
        row.insertCell(0).innerText = new Date(record.created_at).toLocaleString(); // Format the date
        row.insertCell(1).innerText = record.record_type;
        row.insertCell(2).innerText = record.record_value;

        // Create delete button
        const actionsCell = row.insertCell(3); // New cell for actions
        const deleteButton = document.createElement('button');
        deleteButton.innerText = 'Delete';

        // Use the correct property for the record ID
        deleteButton.onclick = () => {
            console.log('Record to delete:', record); // Log the record object
            deleteRecord(record._id); // Ensure this references the correct ID property
        };

        actionsCell.appendChild(deleteButton);
    });
}

// Draw the time series chart
function drawChart(records) {
    const ctx = document.getElementById('myChart').getContext('2d');
    const labels = records.map(record => new Date(record.created_at).toLocaleString());
    const dataValues = records.map(record => record.record_value);

    const data = {
        labels: labels,
        datasets: [{
            label: 'Record Values',
            data: dataValues,
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 2,
            fill: false
        }]
    };

    const config = {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Record Value'
                    },
                    beginAtZero: true
                }
            }
        }
    };

    // Check if myChart exists and destroy it if it does
    if (window.myChart instanceof Chart) {
        window.myChart.destroy();
    }
    
    // Create a new chart
    window.myChart = new Chart(ctx, config);
}

// Function to handle deleting a record
function deleteRecord(recordId) {
    if (confirm('Are you sure you want to delete this record?')) {
        fetch(`http://localhost:8000/deleteRecord/${recordId}`, { // Ensure the correct URL
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json', // Add content type
                'token': localStorage.getItem('token') // Include token for authentication
            }
        })
        .then(response => {
            console.log('Response Status:', response.status);
            return response.json(); // Get the response as JSON
        })
        .then(data => {
            console.log('Response Data:', data); // Log the response data
            if (data.error) {
                document.getElementById('message').innerText = data.error; // Show error message
            } else {
                document.getElementById('message').innerText = 'Record deleted successfully'; // Success message
                fetchRecords(); // Refresh records after deleting
            }
        })
        .catch(error => {
            console.error('Error deleting record:', error);
            document.getElementById('message').innerText = 'An error occurred while deleting the record.';
        });
    }
}

// Event listener for fetching records
document.getElementById('fetch-records-button').addEventListener('click', fetchRecords);

// Call the fetchRecordTypes function on page load
document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    if (token) {
        const decodedToken = jwt_decode(token); // Decode the token to get the username
        const username = decodedToken.username; // Get the username from the token
        // You can optionally fetch record types here if needed
    } else {
        console.error('User is not logged in. Token is missing.');
    }
});