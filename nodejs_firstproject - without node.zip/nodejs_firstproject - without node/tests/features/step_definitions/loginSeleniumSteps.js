const { Given, When, Then, AfterAll } = require('@cucumber/cucumber'); // Use @cucumber/cucumber
const { Builder, By, Capabilities, Key, until } = require('selenium-webdriver'); // Import until
const chai = require('chai'); // CommonJS require
require("chromedriver");

// Driver setup
const capabilities = Capabilities.chrome();
capabilities.set('chromeOptions', { "w3c": false });
const driver = new Builder().withCapabilities(capabilities).build();

Given('I am on the login page', async function () {
    await driver.get('http://localhost:8000/login.html'); // Your login page URL
});

When('I enter valid credentials', async function () {
    const usernameElement = await driver.findElement(By.id('login-username'));
    const passwordElement = await driver.findElement(By.id('login-password'));

    await usernameElement.sendKeys('dorsa'); // Replace with a valid username
    await passwordElement.sendKeys('macky'); // Replace with a valid password
    await passwordElement.sendKeys(Key.RETURN); // Submit the form
});

// This step definition checks for redirection to index.html
Then('I should be redirected to the index page', async function () {
    // Wait for the URL to change to the index page
    await driver.wait(until.urlIs('http://localhost:8000/index.html'), 50000); // Adjust the timeout as necessary
    // Optionally, you can also assert the URL if needed
    const currentUrl = await driver.getCurrentUrl();
    chai.expect(currentUrl).to.equal('http://localhost:8000/index.html'); // Ensure the URL is correct
});

When('I enter invalid credentials', async function () {
    const usernameElement = await driver.findElement(By.id('login-username'));
    const passwordElement = await driver.findElement(By.id('login-password'));

    await usernameElement.sendKeys('invalidUsername'); // Replace with an invalid username
    await passwordElement.sendKeys('invalidPassword'); // Replace with an invalid password
    await passwordElement.sendKeys(Key.RETURN); // Submit the form
});

Then('I should see a login error message', async function () {
    const messageElement = await driver.findElement(By.id('message'));
    const messageText = await messageElement.getText();
    chai.expect(messageText).to.include('User Not Exist'); // Adjust based on the expected error message
});

AfterAll(async function(){
    await driver.quit();
});