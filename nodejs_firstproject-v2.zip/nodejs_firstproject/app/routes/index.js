const diabetesRoutes = require('./diabetes_routes');

module.exports = function(app, db) {
    diabetesRoutes(app, db);
};