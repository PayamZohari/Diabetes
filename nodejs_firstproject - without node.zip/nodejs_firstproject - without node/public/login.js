document.getElementById('login-form').addEventListener('submit', async function (event) {
    event.preventDefault(); // Prevent the default form submission

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await fetch('http://localhost:8000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();
        if (response.ok) {
            localStorage.setItem('token', data.token); // Store the token in local storage
            localStorage.setItem('username', username); // Store the username in local storage
            document.getElementById('message').innerText = 'Login successful!';
            // Redirect to index.html after login
            window.location.href = 'index.html'; // Redirect to index.html instead of dashboard.html
        } else {
            document.getElementById('message').innerText = data.message || 'Login failed.';
        }
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('message').innerText = 'An error occurred during login.';
    }
});