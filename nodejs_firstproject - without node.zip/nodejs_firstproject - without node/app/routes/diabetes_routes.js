//const ObjectID = require('mongodb').ObjectID;
const { ObjectId } = require('mongodb');
const jwt = require('jsonwebtoken');
const auth = require('../../middleware/auth');

        
    

module.exports = function(app, db) {

    app.post('/signup', async (req, res) => {
        console.log('Received request body:', req.body);
    
        const { username, password } = req.body;
    
        // Validate username and password
        if (typeof username !== 'string' || typeof password !== 'string') {
            console.log('Validation failed: Username and password must be strings');
            return res.status(400).send({ error: 'Username and password must be strings' });
        }
    
        if (!username || !password) {
            console.log('Validation failed: Username and password are both required for signup');
            return res.status(400).send({ error: 'Username and password are both required for signup' });
        }
    
        if (password.length <= 6) {
            console.log('Validation failed: Password must be greater than 6 characters');
            return res.status(400).send({ error: 'Password must be greater than 6 characters' });
        }
    
        try {
            // Check if the username already exists
            const existingUser = await db.collection('users').findOne({ username });
            if (existingUser) {
                console.log('Validation failed: Username already exists');
                return res.status(400).send({ error: 'Username already exists' });
            }
    
            // Create the user object
            const user = { username, password, role: "patient", token: "" };
    
            // Insert the new user into the database
            const result = await db.collection('users').insertOne(user);
            res.status(200).send({ message: 'Signup successful!', _id: result.insertedId, username });
        } catch (err) {
            console.error('Error inserting the user:', err);
            res.status(500).send({ error: 'An error has occurred' });
        }
    });
    
  app.post('/login', async(req, res) => {
    const {username , password} = req.body;
    const coll = await db.collection('users');
    try{
        const user = await coll.findOne({username});
        if(!user){
            return res.status(400).json({
                message: "User Not Exist"
              });
        }
         
        if(password != user.password){
            return res.status(400).json({
                message: "Incorrect Password"
              });
        }
        

        const payload = {
            username : user.username ,
            role : user.role
        };
        
        const role = user.role;
        const token = jwt.sign(payload , "secret");
        const inserttoken = await coll.updateOne(user , {$set:{token :  token}});
        res.status(200).json({ token , role  });

    }catch(err){
        console.error(err);
        res.status(500).json({message: "Server Error"});
    } 
});

  app.post('/getUserByToken', auth, async (req, res) => {
    const { token } = req.body; // Extract the token from the request body

    if (!token) {
        return res.status(400).send({ error: 'Token is required' }); // Ensure token is provided
    }

    try {
        // Query the database for a user with the matching token
        const user = await db.collection('users').findOne({ token: token });

        if (!user) {
            // If no user is found, return 400 with an error message
            return res.status(400).send({ error: 'Invalid token' });
        }

        // If user is found, return their role and token with a 200 status
        return res.status(200).send({ username: user.username, role: user.role});
    } catch (err) {
        console.error('Error checking token:', err); // Log any errors for debugging
        res.status(500).send({ error: 'An error has occurred' }); // Respond with internal server error
    }
});





app.post('/addRecord', auth, async (req, res) => {
    console.log('Received request body:', req.body); // Log the request body

    const { created_at, username, record_type, record_value } = req.body;

    // Validate created_at, username, and record_type are strings
    if (typeof created_at !== 'string' || typeof username !== 'string' || typeof record_type !== 'string') {
        return res.status(400).send({ error: 'created_at, username, and record_type must be strings' });
    }

    // Check if all required fields are present
    if (!created_at || !username || !record_type || record_value === undefined) {
        return res.status(400).send({ error: 'created_at, username, record_type and record_value are all required for adding a record' });
    }

    try {
        const createdAt = new Date(created_at);
        // Ensure the dates are valid and after 1970
        if (isNaN(createdAt.getTime()) || createdAt.getFullYear() < 1970) {
            return res.status(400).send({ error: 'Invalid date format for created_at, or date must be after 1970' });
        }

        // Convert record_value to an integer
        const recordValueInt = parseInt(record_value, 10); // Convert string to integer

        // Validate record_value is a positive integer after conversion
        if (!Number.isInteger(recordValueInt) || recordValueInt <= 0) {
            return res.status(400).send({ error: 'record_value must be a positive integer' });
        }

        // Check if the username exists in the users collection
        const userExists = await db.collection('users').findOne({ username });
        if (!userExists) {
            return res.status(400).send({ error: 'Username does not exist' });
        }

        // Check if a record with the same created_at, username, and record_type already exists
        const existingRecord = await db.collection('records').findOne({ created_at, user: username, record_type });
        if (existingRecord) {
            return res.status(400).send({ error: 'A record with the same created_at, username, and record_type already exists' });
        }

        // Create the record object
        const record = { created_at, user: username, record_type, record_value: recordValueInt }; // Use the converted integer value

        // Insert the new record into the database
        const result = await db.collection('records').insertOne(record);
        console.log('Record inserted:', result); // Log the result of the insertion
        res.send({ _id: result.insertedId, ...record }); // Return inserted document
    } catch (err) {
        console.error('Error inserting the record:', err);
        res.status(500).send({ error: 'An error has occurred' });
    }
});

app.post('/getRecords', auth, async (req, res) => {
    console.log('Received request body:', req.body);

    const { username, start_period, end_period, record_type } = req.body;

    // Validate the request body
    if (!username || !start_period || !end_period || !record_type) {
        return res.status(400).send({ error: 'username, start_period, end_period, and record_type are all required' });
    }

    try {
        // Convert start_period and end_period from string to Date object
        const startDate = new Date(start_period);
        const endDate = new Date(end_period);

        // Log the converted dates
        console.log('Converted Start Date:', startDate);
        console.log('Converted End Date:', endDate);

        // Ensure the dates are valid
        if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
            return res.status(400).send({ error: 'Invalid date format for start_period or end_period' });
        }

        // Ensure endDate is after startDate
        if (endDate <= startDate) {
            return res.status(400).send({ error: 'end_period must be after start_period' });
        }

        // Check if the username exists in the users database
        const userExists = await db.collection('users').findOne({ username: username });
        if (!userExists) {
            return res.status(404).send({ error: 'User not found' });
        }

        // Query the records collection
        const records = await db.collection('records').find({
            user: username,
            record_type: record_type,
            created_at: {
                $gte: startDate.toISOString().split('T')[0], // Use YYYY-MM-DD format
                $lt: endDate.toISOString().split('T')[0] // Use YYYY-MM-DD format
            }
        }).toArray();

        // Log the records retrieved
        console.log('Fetched records:', records);

        // Map the records to the desired object format, including _id
        const result = records.map(record => ({
            _id: record._id, // Include the _id field
            created_at: record.created_at,
            record_value: record.record_value,
            record_type: record.record_type // Include record_type if needed
        }));

        // Send the result back to the client
        res.send(result);
    } catch (err) {
        console.error('Error retrieving records:', err);
        res.status(500).send({ error: 'An error has occurred while retrieving records' });
    }
});
    
// Function to validate ObjectId
function isValidObjectId(id) {
    return ObjectId.isValid(id) && (String(new ObjectId(id)) === id);
}

// DELETE route to delete a record
app.delete('/deleteRecord/:id', async (req, res) => {
    const recordId = req.params.id; // Extract ID from the request parameters
    console.log('Received Record ID:', recordId); // Log for debugging

    // Validate the ObjectId
    if (!isValidObjectId(recordId)) {
        return res.status(400).json({ error: 'Invalid record ID format' });
    }

    try {
        const result = await db.collection('records').deleteOne({ _id: new ObjectId(recordId) });
        if (result.deletedCount === 1) {
            return res.status(200).json({ message: 'Record deleted successfully' });
        } else {
            return res.status(404).json({ error: 'Record not found' });
        }
    } catch (error) {
        console.error('Error deleting record:', error);
        return res.status(500).json({ error: 'Internal server error' });
    }
});

// Assuming you have Express and a session management system in place
app.post('/api/logout', auth, async (req, res) => {
    try {
        // Here you can remove the token from your session or database
        // For example, if you're using sessions, you might do:
        req.session.destroy(err => {
            if (err) {
                return res.status(500).send({ error: 'Failed to logout' });
            }
            res.status(200).send({ message: 'Successfully logged out' });
        });

        // If you're using JWT, you might not need to do anything server-side,
        // just ensure the token is removed client-side.
    } catch (error) {
        console.error('Error during logout:', error);
        res.status(500).send({ error: 'An error occurred during logout' });
    }
});

};