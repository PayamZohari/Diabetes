// tests/step_definitions/loginSteps.js
const { Given, When, Then } = require('@cucumber/cucumber');
const request = require('supertest');
const server = require('../../../server.js'); // Ensure this points to your server file

let response;

Given('I am on the login page', async function () {
    // Here, you might want to check if the login page is served correctly
    response = await request(server).get('/login.html'); // Adjust if your login page has a different route
    if (response.status !== 200) {
        throw new Error(`Expected status 200, but got ${response.status}`);
    }
});

When('I enter valid credentials', async function () {
    const username = 'dorsa'; // Replace with a valid username
    const password = 'macky'; // Replace with a valid password
    response = await request(server)
        .post('/login') // Adjust the endpoint as needed
        .send({ username, password });
});

Then('I should be redirected to the dashboard', function () {
    if (response.status !== 200) { // Adjust based on your API's response for successful login
        throw new Error(`Expected status 200, but got ${response.status}`);
    }
    // Optionally check if the response body contains the expected data
    // For example, checking for a token or user role
});

When('I enter invalid credentials', async function () {
    const username = 'invalidUser'; // Replace with an invalid username
    const password = 'invalidPassword'; // Replace with an invalid password
    response = await request(server)
        .post('/login') // Adjust the endpoint as needed
        .send({ username, password });
});

// Implement the error message step
Then('I should see an error message {string}', function (expectedMessage) {
    if (response.status !== 400) { // Check for the correct error status
        throw new Error(`Expected status 400, but got ${response.status}`);
    }
    if (!response.body.message || response.body.message !== expectedMessage) {
        throw new Error(`Expected error message "${expectedMessage}", but got "${response.body.message || 'none'}".`);
    }
});