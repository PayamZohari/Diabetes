// config/db.js

module.exports = {
  url: 'mongodb://payam:payam1380@localhost:27017', // Replace with your MongoDB connection string
  dbName: 'diabetes' // Replace with your database name
};