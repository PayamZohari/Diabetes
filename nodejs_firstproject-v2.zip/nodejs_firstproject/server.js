const express = require('express');
const MongoClient = require('mongodb').MongoClient;
const bodyParser = require('body-parser');
const dbConfig = require('./config/db');
const app = express();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files from the public directory


port = 8000

// Connect to MongoDB
MongoClient.connect(dbConfig.url, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(client => {
        console.log('Connected successfully to database');
        const db = client.db(dbConfig.dbName); // Access the database

        // Require and pass the app and db to your routes
        require('./app/routes')(app, db);

        // Start the server
        app.listen(port, () => {
            console.log('We are live on ' + port);
        });
    })
    .catch(err => {
        console.error('Failed to connect to the database:', err);
        process.exit(1); // Exit the application if the connection fails
    });