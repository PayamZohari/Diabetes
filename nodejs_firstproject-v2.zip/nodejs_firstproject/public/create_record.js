document.getElementById('back-button').addEventListener('click', function() {
    window.location.href = 'http://localhost:8000/dashboard.html'; // Redirect to the dashboard page
});

document.getElementById('create-record-form').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent the default form submission

    const created_at = document.getElementById('created_at').value;
    const record_type = document.getElementById('record_type').value;
    const record_value = document.getElementById('record_value').value;

    const token = localStorage.getItem('token');
    const decodedToken = jwt_decode(token); // This assumes jwt_decode is available globally from the CDN in your HTML
    const username = decodedToken.username; // Get the username from the token

    console.log('Sending record data:', { created_at, username, record_type, record_value }); // Log data being sent

    try {
        const response = await fetch('http://localhost:8000/addRecord', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'token': token
            },
            body: JSON.stringify({ created_at, username, record_type, record_value })
        });

        const data = await response.json();
        console.log('Response from server:', data); // Log the response from the server

        document.getElementById('message').innerText = data.error || 'Record created successfully!';
    } catch (error) {
        console.error('Error creating record:', error);
        document.getElementById('message').innerText = 'An error occurred while creating the record.';
    }
});